function onRequest (context) {
    // var log = new Log("operation-bar.js");
    return context;
}